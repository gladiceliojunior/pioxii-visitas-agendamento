// Configuração
const API_URL = 'http://localhost:3000/api';
let token = localStorage.getItem('adminToken');

// Elementos do DOM
const loginScreen = document.getElementById('loginScreen');
const adminScreen = document.getElementById('adminScreen');
const loginForm = document.getElementById('loginForm');
const loginMensagem = document.getElementById('loginMensagem');
const btnLogout = document.getElementById('btnLogout');
const adminTabBtns = document.querySelectorAll('.admin-tab-btn');
const adminTabContents = document.querySelectorAll('.admin-tab-content');

// Verificar se já está logado
if (token) {
  mostrarTelaAdmin();
} else {
  mostrarTelaLogin();
}

// Event Listeners
loginForm.addEventListener('submit', fazerLogin);
btnLogout.addEventListener('click', fazerLogout);

adminTabBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    const tabName = btn.getAttribute('data-tab');
    mostrarAbaAdmin(tabName);
  });
});

// Funções de Login
async function fazerLogin(e) {
  e.preventDefault();

  const usuario = document.getElementById('usuario').value;
  const senha = document.getElementById('senha').value;

  try {
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ usuario, senha }),
    });

    const data = await response.json();

    if (response.ok) {
      token = data.token;
      localStorage.setItem('adminToken', token);
      mostrarTelaAdmin();
      carregarAgendamentosAdmin();
      carregarHorariosAdmin();
    } else {
      mostrarMensagemLogin(data.erro || 'Erro ao fazer login', 'erro');
    }
  } catch (error) {
    console.error('Erro:', error);
    mostrarMensagemLogin('Erro ao conectar ao servidor', 'erro');
  }
}

function fazerLogout() {
  localStorage.removeItem('adminToken');
  token = null;
  loginForm.reset();
  mostrarTelaLogin();
  mostrarMensagemLogin('', '');
}

function mostrarTelaLogin() {
  loginScreen.classList.add('active');
  adminScreen.classList.remove('active');
}

function mostrarTelaAdmin() {
  loginScreen.classList.remove('active');
  adminScreen.classList.add('active');
}

function mostrarMensagemLogin(texto, tipo) {
  loginMensagem.textContent = texto;
  loginMensagem.className = `mensagem ${tipo}`;

  if (tipo) {
    setTimeout(() => {
      loginMensagem.className = 'mensagem';
    }, 5000);
  }
}

// Abas do Admin
function mostrarAbaAdmin(tabName) {
  adminTabContents.forEach((content) => {
    content.classList.remove('active');
  });

  adminTabBtns.forEach((btn) => {
    btn.classList.remove('active');
  });

  document.getElementById(tabName).classList.add('active');
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

  if (tabName === 'agendamentos') {
    carregarAgendamentosAdmin();
  } else if (tabName === 'horarios') {
    carregarHorariosAdmin();
  }
}

// Carregar Agendamentos Admin
async function carregarAgendamentosAdmin() {
  try {
    const response = await fetch(`${API_URL}/agendamentos`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const agendamentos = await response.json();
    const listaAgendamentosAdmin = document.getElementById('listaAgendamentosAdmin');

    listaAgendamentosAdmin.innerHTML = '';

    if (agendamentos.length === 0) {
      listaAgendamentosAdmin.innerHTML = '<p style="text-align: center; padding: 20px;">Nenhum agendamento realizado ainda.</p>';
      return;
    }

    agendamentos.forEach((agendamento) => {
      const card = document.createElement('div');
      card.className = 'agendamento-admin-card';
      card.innerHTML = `
        <h3>${agendamento.escola}</h3>
        <div class="agendamento-info-grid">
          <div class="info-item">
            <div class="info-label">Data</div>
            <div class="info-value">${formatarData(agendamento.data)}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Horário</div>
            <div class="info-value">${agendamento.horario}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Email</div>
            <div class="info-value">${agendamento.email}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Telefone</div>
            <div class="info-value">${agendamento.telefone || 'Não informado'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Turmas</div>
            <div class="info-value">${agendamento.turmas || 'Não especificado'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Agendado em</div>
            <div class="info-value">${formatarDataHora(agendamento.criado_em)}</div>
          </div>
        </div>
        ${agendamento.observacoes ? `<p><strong>Observações:</strong> ${agendamento.observacoes}</p>` : ''}
        <div class="agendamento-actions">
          <button class="btn-deletar" onclick="deletarAgendamento(${agendamento.id})">Deletar Agendamento</button>
        </div>
      `;

      listaAgendamentosAdmin.appendChild(card);
    });
  } catch (error) {
    console.error('Erro ao carregar agendamentos:', error);
  }
}

// Deletar Agendamento
async function deletarAgendamento(id) {
  if (!confirm('Tem certeza que deseja deletar este agendamento?')) {
    return;
  }

  try {
    const response = await fetch(`${API_URL}/agendamentos/${id}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const data = await response.json();

    if (response.ok) {
      alert('Agendamento deletado com sucesso!');
      carregarAgendamentosAdmin();
    } else {
      alert(data.erro || 'Erro ao deletar agendamento');
    }
  } catch (error) {
    console.error('Erro:', error);
    alert('Erro ao conectar ao servidor');
  }
}

// Carregar Horários Admin
async function carregarHorariosAdmin() {
  try {
    const response = await fetch(`${API_URL}/horarios`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const horarios = await response.json();
    const listaHorariosAdmin = document.getElementById('listaHorariosAdmin');

    listaHorariosAdmin.innerHTML = '';

    if (horarios.length === 0) {
      listaHorariosAdmin.innerHTML = '<p style="text-align: center; padding: 20px;">Nenhum horário disponível.</p>';
      return;
    }

    horarios.forEach((horario) => {
      const card = document.createElement('div');
      card.className = 'horario-card';
      card.innerHTML = `
        <div class="horario-data">${formatarData(horario.data)}</div>
        <div class="horario-hora">${horario.horario}</div>
        <div class="horario-status ${horario.disponivel ? '' : 'ocupado'}">
          ${horario.disponivel ? 'Disponível' : 'Ocupado'}
        </div>
      `;

      listaHorariosAdmin.appendChild(card);
    });
  } catch (error) {
    console.error('Erro ao carregar horários:', error);
  }
}

// Adicionar Horário
document.getElementById('btnAdicionarHorario').addEventListener('click', async () => {
  const data = document.getElementById('dataNovoHorario').value;
  const horario = document.getElementById('horarioNovo').value;
  const mensagemDiv = document.getElementById('mensagemHorario');

  if (!data || !horario) {
    mostrarMensagem(mensagemDiv, 'Por favor, preencha todos os campos', 'erro');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/horarios`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ data, horario }),
    });

    const result = await response.json();

    if (response.ok) {
      mostrarMensagem(mensagemDiv, 'Horário adicionado com sucesso!', 'sucesso');
      document.getElementById('dataNovoHorario').value = '';
      document.getElementById('horarioNovo').value = '';
      carregarHorariosAdmin();
    } else {
      mostrarMensagem(mensagemDiv, result.erro || 'Erro ao adicionar horário', 'erro');
    }
  } catch (error) {
    console.error('Erro:', error);
    mostrarMensagem(mensagemDiv, 'Erro ao conectar ao servidor', 'erro');
  }
});

// Funções auxiliares
function formatarData(dataStr) {
  const opcoes = { year: 'numeric', month: '2-digit', day: '2-digit' };
  const data = new Date(dataStr + 'T00:00:00');
  return data.toLocaleDateString('pt-BR', opcoes);
}

function formatarDataHora(dataHoraStr) {
  if (!dataHoraStr) return '';
  const opcoes = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  };
  const data = new Date(dataHoraStr);
  return data.toLocaleDateString('pt-BR', opcoes);
}

function mostrarMensagem(elemento, texto, tipo) {
  elemento.textContent = texto;
  elemento.className = `mensagem ${tipo}`;

  setTimeout(() => {
    elemento.className = 'mensagem';
  }, 5000);
}

// Definir data mínima como hoje
document.getElementById('dataNovoHorario').min = new Date().toISOString().split('T')[0];

