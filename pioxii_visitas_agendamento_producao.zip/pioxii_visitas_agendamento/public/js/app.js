// Configuração da API
const API_URL = 'http://localhost:3000/api';

// Elementos do DOM
const formAgendamento = document.getElementById('formAgendamento');
const mensagemDiv = document.getElementById('mensagem');
const tabBtns = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');
const calendarioView = document.getElementById('calendarioView');
const listaAgendamentos = document.getElementById('listaAgendamentos');

// Event Listeners para abas
tabBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    const tabName = btn.getAttribute('data-tab');
    mostrarAba(tabName);
  });
});

// Função para mostrar aba
function mostrarAba(tabName) {
  tabContents.forEach((content) => {
    content.classList.remove('active');
  });

  tabBtns.forEach((btn) => {
    btn.classList.remove('active');
  });

  document.getElementById(tabName).classList.add('active');
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

  // Carregar dados quando abrir abas específicas
  if (tabName === 'calendario') {
    carregarCalendario();
  } else if (tabName === 'agendamentos') {
    carregarAgendamentos();
  }
}

// Formulário de agendamento
formAgendamento.addEventListener('submit', async (e) => {
  e.preventDefault();

  const formData = {
    escola: document.getElementById('escola').value,
    email: document.getElementById('email').value,
    telefone: document.getElementById('telefone').value,
    data: document.getElementById('data').value,
    horario: document.getElementById('horario').value,
    turmas: document.getElementById('turmas').value,
    observacoes: document.getElementById('observacoes').value,
  };

  try {
    const response = await fetch(`${API_URL}/agendamentos`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    });

    const data = await response.json();

    if (response.ok) {
      mostrarMensagem('Agendamento realizado com sucesso! Um email foi enviado para a PIOXII.', 'sucesso');
      formAgendamento.reset();
      setTimeout(() => {
        mostrarAba('agendamentos');
        carregarAgendamentos();
      }, 1500);
    } else {
      mostrarMensagem(data.erro || 'Erro ao realizar agendamento', 'erro');
    }
  } catch (error) {
    console.error('Erro:', error);
    mostrarMensagem('Erro ao conectar ao servidor', 'erro');
  }
});

// Função para mostrar mensagem
function mostrarMensagem(texto, tipo) {
  mensagemDiv.textContent = texto;
  mensagemDiv.className = `mensagem ${tipo}`;

  setTimeout(() => {
    mensagemDiv.className = 'mensagem';
  }, 5000);
}

// Carregar calendário
async function carregarCalendario() {
  try {
    const response = await fetch(`${API_URL}/horarios`);
    const horarios = await response.json();

    const agendamentosResponse = await fetch(`${API_URL}/agendamentos`);
    const agendamentos = await agendamentosResponse.json();

    // Criar mapa de horários ocupados
    const horariosOcupados = new Set();
    agendamentos.forEach((agendamento) => {
      horariosOcupados.add(`${agendamento.data}-${agendamento.horario}`);
    });

    calendarioView.innerHTML = '';

    if (horarios.length === 0) {
      calendarioView.innerHTML = '<p style="grid-column: 1/-1; text-align: center; padding: 20px;">Nenhum horário disponível no momento.</p>';
      return;
    }

    horarios.forEach((horario) => {
      const diaDiv = document.createElement('div');
      const chave = `${horario.data}-${horario.horario}`;
      const estaOcupado = horariosOcupados.has(chave);

      diaDiv.className = `dia ${estaOcupado ? 'ocupado' : ''}`;
      diaDiv.innerHTML = `
        <div class="dia-data">${formatarData(horario.data)}</div>
        <div class="dia-hora">${horario.horario}</div>
        ${estaOcupado ? '<div class="dia-status">✓ Agendado</div>' : ''}
      `;

      if (!estaOcupado) {
        diaDiv.addEventListener('click', () => {
          document.getElementById('data').value = horario.data;
          document.getElementById('horario').value = horario.horario;
          mostrarAba('agendamento');
          window.scrollTo(0, 0);
        });
      }

      calendarioView.appendChild(diaDiv);
    });
  } catch (error) {
    console.error('Erro ao carregar calendário:', error);
    calendarioView.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: red;">Erro ao carregar calendário</p>';
  }
}

// Carregar agendamentos
async function carregarAgendamentos() {
  try {
    const response = await fetch(`${API_URL}/agendamentos`);
    const agendamentos = await response.json();

    listaAgendamentos.innerHTML = '';

    if (agendamentos.length === 0) {
      listaAgendamentos.innerHTML = '<p style="text-align: center; padding: 20px;">Nenhum agendamento realizado ainda.</p>';
      return;
    }

    agendamentos.forEach((agendamento) => {
      const card = document.createElement('div');
      card.className = 'agendamento-card ocupado';
      card.innerHTML = `
        <h3>${agendamento.escola}</h3>
        <div class="agendamento-info">
          <div class="info-item">
            <div class="info-label">Data</div>
            <div class="info-value">${formatarData(agendamento.data)}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Horário</div>
            <div class="info-value">${agendamento.horario}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Email</div>
            <div class="info-value">${agendamento.email}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Telefone</div>
            <div class="info-value">${agendamento.telefone || 'Não informado'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Turmas</div>
            <div class="info-value">${agendamento.turmas || 'Não especificado'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Agendado em</div>
            <div class="info-value">${formatarDataHora(agendamento.criado_em)}</div>
          </div>
        </div>
        ${agendamento.observacoes ? `<p><strong>Observações:</strong> ${agendamento.observacoes}</p>` : ''}
      `;

      listaAgendamentos.appendChild(card);
    });
  } catch (error) {
    console.error('Erro ao carregar agendamentos:', error);
    listaAgendamentos.innerHTML = '<p style="text-align: center; color: red;">Erro ao carregar agendamentos</p>';
  }
}

// Função para formatar data
function formatarData(dataStr) {
  const opcoes = { year: 'numeric', month: '2-digit', day: '2-digit' };
  const data = new Date(dataStr + 'T00:00:00');
  return data.toLocaleDateString('pt-BR', opcoes);
}

// Função para formatar data e hora
function formatarDataHora(dataHoraStr) {
  if (!dataHoraStr) return '';
  const opcoes = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  };
  const data = new Date(dataHoraStr);
  return data.toLocaleDateString('pt-BR', opcoes);
}

// Definir data mínima como hoje
document.getElementById('data').min = new Date().toISOString().split('T')[0];

// Carregar agendamentos na inicialização
carregarAgendamentos();

